﻿function ConfirmDelete() {
    return confirm("Are you sure?");
}