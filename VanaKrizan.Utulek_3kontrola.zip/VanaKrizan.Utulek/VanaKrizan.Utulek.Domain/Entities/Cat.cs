﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VanaKrizan.Utulek.Domain.Entities
{
    public class Cat : Pet
    {

    public bool? Chip { get; set; }

    // public double Cost { get; set; }

    }
}
