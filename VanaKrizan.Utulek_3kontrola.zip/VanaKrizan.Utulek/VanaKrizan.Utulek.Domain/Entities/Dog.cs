﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VanaKrizan.Utulek.Domain.Entities
{
    public class Dog : Pet
    {

    public int? SizeId { get; set; }
    public bool? Chip { get; set; }

    // public double Cost { get; set; }

    }
}
